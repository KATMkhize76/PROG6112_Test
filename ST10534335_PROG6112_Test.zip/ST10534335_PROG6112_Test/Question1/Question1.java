/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1;



import java.util.Scanner;
public class Question1 {





    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};
        String[] beverages = {"COFFEE", "TEA", "BOBA TEA"};

        double[][] sales = new double[3][3];

        System.out.println("NUMBER 1 COFFEE HUT APPLICATION");
        System.out.println();

        // Populate the 2D array
        for (int row = 0; row < cities.length; row++) {
            for (int col = 0; col < beverages.length; col++) {

                System.out.print("Enter the number of "
                        + beverages[col]
                        + " sales for "
                        + cities[row]
                        + ": ");

                sales[row][col] = input.nextDouble();
            }
        }

        System.out.println("\nNUMBER 1 COFFEE HUT REPORT");
        System.out.println("-------------------------------------------------------------");

        System.out.printf("%-20s %-12s %-12s %-12s%n",
                "", "COFFEE", "TEA", "BOBA TEA");

        // Display report
        for (int row = 0; row < cities.length; row++) {

            System.out.printf("%-20s", cities[row]);

            for (int col = 0; col < beverages.length; col++) {
                System.out.printf("%-12.2f", sales[row][col]);
            }

            System.out.println();
        }

        System.out.println("\nPRODUCT SALES TOTALS FOR EACH CITY");
        System.out.println("-------------------------------------------------------------");

        double grandTotal = 0;

        for (int row = 0; row < cities.length; row++) {

            double cityTotal = 0;

            for (int col = 0; col < beverages.length; col++) {
                cityTotal += sales[row][col];
            }

            grandTotal += cityTotal;

            System.out.printf("%-20s R%.2f%n",
                    cities[row], cityTotal);
        }

        System.out.println();
        System.out.printf("TOTAL SALES FOR CITIES: R%.2f%n", grandTotal);

        input.close();
    }
}