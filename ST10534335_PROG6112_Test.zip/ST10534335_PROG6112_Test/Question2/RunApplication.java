import java.util.Scanner;

public class RunApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] beverageTypes = {"COFFEE", "TEA", "BOBA"};

        System.out.println("Select the beverage type");
        for (int i = 0; i < beverageTypes.length; i++) {
            System.out.println((i + 1) + ") " + beverageTypes[i]);
        }

        int choice = readChoice(scanner, beverageTypes.length);
        String beverageType = beverageTypes[choice - 1];

        String city;
        do {
            System.out.print("Enter the city: ");
            city = scanner.nextLine().trim().toUpperCase();
            if (city.isEmpty()) {
                System.out.println("City cannot be blank. Please try again.");
            }
        } while (city.isEmpty());

        int totalSales = readTotalSales(scanner, beverageType, city);

        BeverageSales sales = new BeverageSales(beverageType, city, totalSales);
        sales.printReport();
        scanner.close();
    }

    private static int readChoice(Scanner scanner, int numberOfOptions) {
        while (true) {
            System.out.print("Enter your choice (1-" + numberOfOptions + "): ");
            String input = scanner.nextLine().trim();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= numberOfOptions) {
                    return choice;
                }
            } catch (NumberFormatException ignored) {
                // Show the same clear prompt for non-numeric input.
            }
            System.out.println("Invalid selection. Please enter a number from 1 to " + numberOfOptions + ".");
        }
    }

    private static int readTotalSales(Scanner scanner, String beverageType, String city) {
        while (true) {
            System.out.print("Enter the total sales of " + beverageType + " beverages in " + city + ": ");
            String input = scanner.nextLine().trim();
            try {
                int totalSales = Integer.parseInt(input);
                if (totalSales >= 0) {
                    return totalSales;
                }
            } catch (NumberFormatException ignored) {
                // Show a clear prompt for non-numeric input.
            }
            System.out.println("Invalid sales amount. Enter a whole number that is zero or greater.");
        }
    }
}
